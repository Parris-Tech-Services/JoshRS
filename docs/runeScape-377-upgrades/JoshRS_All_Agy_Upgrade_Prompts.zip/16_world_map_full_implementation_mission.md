# World Map Full Implementation Mission

# Agy Mission: Gielinor Interactive World Map & Fast Travel Network

## Mission

Upgrade my locally hosted **RuneScape 2 release #377** into a more enjoyable exploration experience by implementing a fully functional, interactive world map with a modern teleport network.

**Project locations:**
- Server: `~/lostcity377/engine`
- Client: `~/lostcity377/client-java`
- Game content: `~/lostcity377/content`
- Character: `elrothiro`

**This is an implementation task, not a planning exercise.** Investigate the existing code, implement working features, test them, and verify the results in the actual game.

Do not stop after writing documentation, creating mockups or identifying potential approaches.

## 1. Protect the existing working game

My RuneScape #377 server and Java client are currently working.

Before making changes:

1. Inspect the Git status and current modifications across all three project directories.
2. Identify existing processes, server ports and client launch arguments.
3. Back up `data/players/main/elrothiro.sav` and any relevant databases or configuration files.
4. Inspect existing admin commands and customisations.
5. Preserve the current resizable Java client.
6. Preserve infinite run energy.
7. Preserve admin teleport and guild-access modifications.
8. Preserve the Amulet of Fury, inventory, equipment, stats, quest progression and bank.
9. Do not overwrite uncommitted changes from previous Agy work.
10. Do not terminate a healthy server just to start another one.

The server previously used TCP port `52402` and web port `8888`, with Java client offset `8808`. Verify current configuration rather than assuming it is unchanged.

Use safe server restarts only when necessary, ensuring character state is saved.

## 2. Implement a beautiful interactive Gielinor world map

Create a map inspired by modern RuneScape and OSRS while preserving the original 2006-era graphics and atmosphere.

The map should provide:

- A complete map of supported playable regions.
- Smooth zooming and panning.
- Click-and-drag navigation.
- Mouse-wheel zoom.
- Named towns, villages, guilds and landmarks.
- Searchable destinations.
- Clear teleport destination markers.
- A live marker showing my character's actual location.
- Favourites for frequently visited locations.
- Tooltips describing destinations.
- Accessible, readable controls at different window sizes.
- Persistent map preferences.

Use the existing #377 map assets where technically and legally appropriate. Investigate current map data, coordinate systems, cache formats and client rendering capabilities.

Do not invent a visually impressive map that doesn't correspond to the real game world.

### Integration priority

Prefer this order:

1. A functional in-game map interface compatible with the existing Java client.
2. A map integrated into the existing resizable client window.
3. A separate local companion map only if the original client cannot reasonably support the required interactions.

If using a companion map, it must communicate with the existing authenticated server and actually control the logged-in character, not merely show an unrelated map.

Preserve the current game interface and existing client functionality.

## 3. Build the teleport destination network

Add useful, verified destinations across Gielinor.

Initial destinations should include:

**Major cities**
- Varrock
- Lumbridge
- Falador
- Al Kharid
- Draynor Village
- Edgeville
- Barbarian Village
- Port Sarim
- Camelot
- Seers' Village
- Catherby
- East Ardougne
- West Ardougne
- Yanille

**Useful training locations**
- Al Kharid Mine
- Mining Guild
- Fishing Guild
- Crafting Guild
- Champions' Guild
- Wizards' Guild
- Varrock Sewers
- Edgeville Dungeon
- Barbarian Village training areas

**Other interesting destinations**
- Taverley
- Burthorpe
- Rimmington
- Brimhaven
- Karamja
- Tree Gnome Stronghold
- Castle Wars
- Supported minigames and boss locations

Verify every destination exists in this #377 world before enabling it.

For each destination:

1. Identify its correct coordinates.
2. Confirm the map region is loaded.
3. Confirm the destination is reachable.
4. Select a safe, walkable landing tile.
5. Validate its plane and instance requirements.
6. Avoid walls, inaccessible rooms and invalid map regions.
7. Respect dangerous areas and explain their risks.
8. Prevent teleporting into unfinished or restricted content accidentally.

Do not assume modern RuneScape map locations are present in this historical release.

## 4. Click-to-teleport functionality

Make teleporting genuinely work.

When I select a destination:

1. Display the destination name.
2. Offer a clear teleport action.
3. Send the request to the game server.
4. Validate the request server-side.
5. Move my character to the correct coordinates.
6. Update the player position and map marker.
7. Play an existing appropriate teleport animation where supported.
8. Maintain normal game networking and synchronization.
9. Confirm the character arrives safely.

For my admin character `elrothiro`, provide an option for free, unlimited fast travel without consuming runes.

Preserve normal rune-based teleport mechanics for regular players.

**Never trust arbitrary client-supplied coordinates.** Use a server-controlled destination registry with validated destination identifiers.

Admin-only access must use the existing authenticated permission system.

## 5. Create a physical teleport portal hub

Investigate whether existing #377 assets support building a portal hub.

If feasible, create an attractive, functional fast-travel area, preferably somewhere accessible from Varrock.

Include:

- A central teleport area.
- Clearly distinguishable portals.
- Destination names.
- Functional interaction scripts.
- Appropriate portal effects and sounds where available.
- A return-to-hub option.
- Safe arrival positions.
- Optional nearby banking access.

Do not add non-functional decorative portals.

If placing objects requires modifying game content or repacking caches, follow the project's existing tools and build processes.

Avoid interfering with quests, existing NPCs, collision, or important world objects.

## 6. Add a teleport guide

Where practical, implement an NPC or in-game menu offering useful teleport options.

The guide should:

- Present destinations organised by region.
- Provide city and training teleports.
- Display useful destination descriptions.
- Support return-to-home functionality.
- Work with existing #377 dialogue systems.
- Respect admin access controls.

Use existing NPC assets where appropriate.

## 7. Search, favourites and quality-of-life controls

Add:

- Search by destination name.
- Favourites.
- Recently visited locations.
- Region filters.
- City, training, guild and dungeon categories.
- Quick return to Varrock.
- Last destination shortcut.
- Optional confirmation before dangerous teleports.
- Persistent preferences where supported.

Ensure the UI remains practical and uncluttered.

## 8. Preserve the classic gameplay experience

The new system must not break:

- Existing teleports.
- Magic spells.
- Rune consumption for normal players.
- Combat.
- Walking and pathfinding.
- Quest progression.
- NPC interactions.
- Banks and shops.
- Equipment and inventory.
- Multiplayer synchronisation.
- Existing account saves.
- The customised resizable Java client.
- The infinite run modification.
- Existing admin commands.

Keep modern conveniences optional where sensible.

## 9. Implement a reliable testing suite

Create meaningful automated tests covering:

- Destination registry validation.
- Correct destination coordinates.
- Invalid destination rejection.
- Admin permission enforcement.
- Normal-player access restrictions.
- Teleport completion.
- Player position synchronisation.
- Map marker updates.
- Preferences persistence.
- Character save and restoration.
- Reconnection behaviour.
- Repeated teleport use without crashes.
- Handling disconnected clients.
- Dangerous destination confirmation.

Test at least ten distinct destinations.

Do not treat compilation alone as proof of a working teleport network.

## 10. Verify actual gameplay

Launch the real #377 server and Java client.

Perform real gameplay tests with `elrothiro`:

1. Log into the game.
2. Open the interactive map.
3. Confirm the current position marker is accurate.
4. Zoom and pan.
5. Search for Varrock.
6. Teleport to Varrock.
7. Confirm the correct arrival location.
8. Teleport to Falador.
9. Teleport to Lumbridge.
10. Teleport to Al Kharid.
11. Teleport to Yanille.
12. Test additional supported destinations.
13. Test the physical portal hub if implemented.
14. Verify movement and interactions after teleporting.
15. Log out and reconnect.
16. Confirm player position, inventory and equipment are preserved.

Where direct GUI interaction is unavailable, distinguish automated protocol verification from actual visual gameplay verification. Do not claim to have visually tested something you haven't.

## 11. Build and deployment

Complete the required build and deployment work for affected projects.

- Compile the server.
- Rebuild content packs where necessary.
- Rebuild the Java client if changed.
- Run lint and automated tests.
- Resolve introduced build errors.
- Preserve existing modifications.
- Start exactly one server instance.
- Verify the configured ports.
- Launch the updated client.
- Verify a real login and teleport.

Do not automatically kill unrelated processes.

Do not force-push or discard working changes.

Commit coherent, tested changes with descriptive commit messages. Do not publish anything externally unless the destination and permissions are already established.

## 12. Deliver a verification report

Provide:

**VERIFIED COMPLETE**
- Features actually implemented and tested.
- Successful teleport destinations.
- Working map interactions.
- Successful client/server tests.

**PARTIALLY COMPLETE**
- Features implemented but not fully tested.
- Missing client features.
- Limitations caused by the historical #377 engine.

**BLOCKED**
- Genuine technical or permission blockers.
- What was attempted and why it failed.

Also provide:

- Files changed.
- Commits created.
- Build and test results.
- Actual client launch commands.
- Actual server startup commands.
- Remaining bugs.
- Next logical improvements.

## Final instruction

Do not replace my existing working RuneScape game with a prototype.

Do not restart from a fresh copy of the repository.

Do not overwrite my character or existing upgrades.

Choose technically sound solutions that work with the real historical #377 client and server.

**The final result should be a genuinely playable RuneScape world with a functional interactive map, safe teleport network and useful fast-travel experience.**

Implement the highest-value working features first, verify each slice, and continue independently through the next logical steps without repeatedly asking for permission.

Prioritise a real working outcome over impressive-looking but disconnected interfaces.
