# Server Stability And Android Lan

Continue from your previous RuneScape #377 work without starting over.

**First priority: restore and verify the game server.**

1. Inspect the current code changes, processes and listening ports in `~/lostcity377/engine`.
2. Finish the incomplete startup and port-conflict repair in `app.ts` and `TcpServer.ts`.
3. Prevent duplicate server launches safely. Do not automatically terminate unrelated or healthy processes.
4. Preserve `elrothiro.sav`, inventory, equipment, stats and backups.
5. Start exactly one working #377 server.
6. Verify ports 52402 and 8888.
7. Rebuild and launch the customised Java client.
8. Verify actual login, movement, logout, reconnection and saved progress.

**Then investigate playing from my Android phone over the same Wi-Fi network.**

Prioritise a compatible mobile browser client if achievable. Otherwise provide a working free local-network streaming solution using my existing Fedora Java client.

Test connectivity from another device where available, retain the existing resizable-client upgrades, and report VERIFIED COMPLETE, PARTIALLY COMPLETE or BLOCKED accurately.

Do not stop at planning. Implement and test everything technically possible without damaging my existing character or game files.
