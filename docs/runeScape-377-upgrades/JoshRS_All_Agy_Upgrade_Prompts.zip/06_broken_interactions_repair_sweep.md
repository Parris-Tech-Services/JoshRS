# Broken Interactions Repair Sweep

In my self-hosted RuneScape 2 release #377 server, stop building new features for now and focus on fixing broken gameplay interactions and missing content triggers.

I am seeing messages like:
- "No trigger for ..."
- "Nothing interesting happens."

I want a systematic broken-content repair sweep.

Do this:
1. Inspect the client/server logs, trigger system, interaction handlers, scripts, object actions, NPC actions, shop handlers, dialogue handlers, and any "no trigger" / fallback paths.
2. Find the specific source of messages like:
   - "No trigger for Doppl1,favour_bassie_slipcast"
   - "No trigger for [similar interaction keys]"
   - repeated "Nothing interesting happens."
3. Implement the missing scripts or correctly wire the missing triggers so these interactions actually work.
4. Prioritise core gameplay around Varrock and nearby commonly visited areas first:
   - shops and trade interactions
   - doors, gates, ladders, stairs
   - bank booths and bankers
   - guild entrances
   - basic NPC dialogues
   - obvious world objects players expect to work
5. Add sensible fallback handling:
   - if an interaction is intentionally unsupported, give a clear player-facing message
   - log enough detail for future debugging
   - do not silently fail
6. Create a repeatable audit approach:
   - scan for unreferenced or missing trigger keys
   - identify broken object/NPC interactions
   - list high-priority missing gameplay scripts
7. Preserve existing saves, combat, inventory, equipment, pathing, and multiplayer behaviour.
8. Back up my player save before major changes, especially data/players/main/elrothiro.sav.
9. Build and test the game after fixes.
10. Verify in-game with real interaction tests, not just code inspection.

Deliverables:
- fix the broken interactions you can confirm
- report exactly which files changed
- list each repaired interaction
- list remaining broken interactions still needing work
- do not claim completion unless you actually tested the repaired interactions in-game

Focus on making the world feel playable and reliable before adding more custom features.
