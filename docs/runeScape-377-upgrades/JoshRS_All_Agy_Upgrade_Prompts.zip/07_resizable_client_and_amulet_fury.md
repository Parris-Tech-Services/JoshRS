# Resizable Client And Amulet Fury

Upgrade my local RuneScape release #377 project at ~/lostcity377/engine with TWO features.

1. RESIZABLE CLIENT
Inspect the actual desktop client and renderer. Implement window resizing, maximising and fullscreen. Preserve the classic RuneScape interface but allow 1x, 1.5x, 2x and fit-to-window scaling. Correct mouse coordinates, menus, inventory clicks and minimap interactions at every scale. Preserve aspect ratio and save display preferences. If feasible, add an optional expanded 3D viewport. Do not stretch the game incorrectly or break controls.

2. AMULET OF FURY
Inspect the #377 item definitions and equipment system. Confirm the Amulet of Fury is supported. If it exists, give my character elrothiro one legitimate item instance using the existing admin/item mechanisms, equip it in the amulet slot and verify its actual combat bonuses. If unsupported, identify the best existing all-round amulet and use that instead. Do not invent incompatible item IDs or assets.

Before changes, back up data/players/main/elrothiro.sav and preserve existing progress, inventory and infinite run.

Implement both improvements, build, run tests, restart safely, test the actual Java client visually and verify character persistence after reconnecting. Fix failures rather than stopping at the first error.

Report verified results, files changed and any genuinely blocked work.
