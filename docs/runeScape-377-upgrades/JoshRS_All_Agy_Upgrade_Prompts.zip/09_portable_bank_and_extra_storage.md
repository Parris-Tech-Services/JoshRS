# Portable Bank And Extra Storage

Upgrade my self-hosted RuneScape #377 server with an admin-only portable bank and optional expanded storage. Inspect existing bank, inventory, item persistence and interface code. Implement a command or in-game button that opens my bank anywhere, with safe deposit and withdrawal. Keep the original 28 inventory slots compatible with the client. If feasible, add a separate storage bag rather than changing the inventory packet format. Back up elrothiro's save, build, test actual item transfers, restart and verify nothing is lost or duplicated.
