# Java Client Connection Fix

Fix the RuneScape #377 Java client's 'Error connecting to server' problem. The correct server is already running as PID 2121514 in ~/lostcity377/engine, listening successfully on 52402 and 8888. Do not start a second server or kill the healthy process. Inspect the Java client's actual login host/port, runtime arguments and networking code. Identify and repair any mismatch with port 52402. Rebuild the client, launch it, verify a real game login, and preserve elrothiro's save and existing resizable-client upgrades. Report actual verification results.
