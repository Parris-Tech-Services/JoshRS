# Champions Guild Admin Bypass

In my self-hosted RuneScape #377 server, find the Champions' Guild entrance quest-point check. Add an admin-only bypass so my account can enter without 32 quest points. Preserve the normal requirement for regular players. Build, restart and verify that the door opens and Scavvo's Rune Store works. Do not modify unrelated guild requirements.
