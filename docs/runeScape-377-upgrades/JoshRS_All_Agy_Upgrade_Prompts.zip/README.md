# JoshRS — Agy upgrade prompt archive

16 individual prompts from our RuneScape #377 conversation.

These are prompts previously supplied for Agy/Antigravity (plus one Codex-compatible prompt), not a claim that all features were implemented. The archive includes both feature upgrades and related repair/stability prompts, and may contain superseded instructions.

## Contents

- [01_infinite_run_energy.md](01_infinite_run_energy.md)
- [02_interactive_world_map_initial.md](02_interactive_world_map_initial.md)
- [03_champions_guild_admin_bypass.md](03_champions_guild_admin_bypass.md)
- [04_ultimate_gear_manager.md](04_ultimate_gear_manager.md)
- [05_resizable_client_initial.md](05_resizable_client_initial.md)
- [06_broken_interactions_repair_sweep.md](06_broken_interactions_repair_sweep.md)
- [07_resizable_client_and_amulet_fury.md](07_resizable_client_and_amulet_fury.md)
- [08_rune_shield_and_amulet.md](08_rune_shield_and_amulet.md)
- [09_portable_bank_and_extra_storage.md](09_portable_bank_and_extra_storage.md)
- [10_admin_quality_of_life_centre.md](10_admin_quality_of_life_centre.md)
- [11_server_port_conflict_and_login_fix.md](11_server_port_conflict_and_login_fix.md)
- [12_java_client_connection_fix.md](12_java_client_connection_fix.md)
- [13_server_stability_and_android_lan.md](13_server_stability_and_android_lan.md)
- [14_mobile_access_without_interruptions.md](14_mobile_access_without_interruptions.md)
- [15_extended_skills_level_200.md](15_extended_skills_level_200.md)
- [16_world_map_full_implementation_mission.md](16_world_map_full_implementation_mission.md)

## Notes

- Source: prompts visible in the current conversation.
- No source code or player save data is included.
- Some older prompts refer to a then-current PID; do not reuse those PIDs without checking the live process.
- The latest, comprehensive world-map prompt is file 16.
- Check current files, backups and running game state before executing any prompt.
