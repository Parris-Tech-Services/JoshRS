# Interactive World Map Initial

Upgrade my self-hosted RuneScape 2 release #377 server with a modern Gielinor World Map and Fast Travel Network.

First inspect the actual client and server source, existing maps, coordinates, teleport handlers, interfaces and relevant assets. Do not assume modern RuneScape client features exist.

Build the best supported solution:
1. A zoomable, pannable world map with named destinations and a player-location marker.
2. Searchable teleport destinations including Lumbridge, Varrock, Falador, Al Kharid, Draynor, Edgeville and other verified accessible areas.
3. Click-to-teleport functionality authorised and validated server-side, with safe landing coordinates.
4. No rune cost for admin-enabled fast travel.
5. Optional discovered-only destinations, favourites and an admin teleport toggle.
6. A physical portal hub with functional portals, if supported by existing world objects and scripts.
7. A working map button or compatible in-game entry point. If the #377 Java client cannot support a full map safely, implement a local companion map connected to authenticated server actions instead.
8. Preserve original graphics, normal teleports, combat, quests, multiplayer and saved progression.
9. Do not allow arbitrary client-supplied coordinates or bypass legitimate access requirements for restricted areas.

Implement the highest-quality working version, build and test it, restart the server, and verify real teleportation in-game. Report files changed, features verified and any limitations. Do not stop at planning or claim untested functionality works.
