# Admin Quality Of Life Centre

Continue upgrading my self-hosted RuneScape #377 project at ~/lostcity377/engine.

Build an admin-only Quality of Life Control Centre, starting with:
1. Safe instant reconnection after unexpected disconnects, preserving combat/logout safety.
2. A searchable item and equipment manager with validated item spawning and saved loadouts.
3. A world map and fast travel system with safe server-validated teleport destinations.
4. Admin-only guild and quest access controls without changing ordinary player progression.
5. Settings for infinite run, XP multipliers and other server-side quality-of-life features.

First inspect the real source, existing changes, client capabilities, player persistence and current server process. Preserve my character elrothiro, items, stats and save data. Back up player saves before any risky changes.

Implement in small, working slices. Prefer existing interfaces and commands over speculative client modifications. Do not overwrite Agy's verified infinite-run change. Never leave two conflicting game-server processes running.

For each slice: implement, build, lint, test, restart safely, verify live behaviour, and record what actually works. Continue through the next logical slice without asking for approval. Report VERIFIED COMPLETE, PARTIALLY COMPLETE or BLOCKED accurately.
