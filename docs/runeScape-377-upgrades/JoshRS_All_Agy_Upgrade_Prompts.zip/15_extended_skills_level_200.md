# Extended Skills Level 200

Implement extended skill progression up to level 200 in my RuneScape #377 installation at ~/lostcity377/engine, with client at ~/lostcity377/client-java and content at ~/lostcity377/content.

Preserve my existing working server, player elrothiro, all current XP, inventory, equipment, quests, bank, infinite run, admin upgrades, teleport changes and resizable client. Back up player saves and related databases before editing. Do not reset level 99 skills or silently alter earned XP.

Use the exact original RuneScape experience formula, extended to level 200. Verify the original XP thresholds through level 99 remain unchanged. Investigate every server/client hardcoded level-99 cap, XP cap, lookup table, integer/fixed-point representation, stat-update packet, skills interface, level-up handler, save/load parser, combat formula, Prayer and Hitpoints mechanics, requirements and skill boosts.

The original 200m XP storage cap cannot represent level 200. Design overflow-safe XP persistence and calculations, using an exact representation where necessary. Do not send oversized integers through existing 32-bit packets. Where the original protocol cannot represent extended XP, preserve a compatible wire value and implement a safe extension for full XP and levels. Never truncate or corrupt saved XP.

Make the level cap configurable: classic 99 or extended 120, 150 and 200. Add configurable XP multipliers of 1x, 5x, 10x and 50x, defaulting to 1x. Cap changes must never delete accumulated XP.

Update skill displays to show correct extended levels and progress to the next level. Make Prayer restoration, maximum Prayer, combat calculations and boosted/drained levels work safely. Do not invent post-99 content unlocks; preserve existing requirements unless explicitly extended.

Add tests for XP thresholds at levels 1, 50, 99, 100, 120, 150 and 200; XP overflow; level changes; client display; XP grants; reconnect; persistence; and switching caps without data loss.

Implement in safe verified slices. Build and lint all affected projects. Launch the real client and server and verify earning XP above level 99, showing the correct level, and retaining XP after logout/restart. Preserve the existing active server until a controlled changeover is necessary. Report exact file changes, tests, and VERIFIED COMPLETE / PARTIALLY COMPLETE / BLOCKED honestly. Do not stop at a roadmap.
