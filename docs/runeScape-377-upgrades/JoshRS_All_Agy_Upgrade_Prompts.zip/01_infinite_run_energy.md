# Infinite Run Energy

Implement infinite run energy in my self-hosted RuneScape 2 release #377 server.

Locate the server-side run-energy drain and regeneration logic (likely engine/src/engine/entity/Player.ts).

Modify it so run energy stays at 100% while running, never drains, and remains compatible with the existing client.

Keep the change minimal and server-side.

Then build the project, run relevant tests, restart the local server, and verify in-game that continuous running does not reduce energy.

Report the changed files and actual verification results. Do not claim success unless tested.
