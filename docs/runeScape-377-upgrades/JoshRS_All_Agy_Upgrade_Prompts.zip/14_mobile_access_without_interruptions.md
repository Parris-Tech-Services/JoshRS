# Mobile Access Without Interruptions

The server and client are already working. Do not restart, replace or repair them unnecessarily. Preserve my active game session and character data. Focus on enabling Android phone gameplay over local Wi-Fi, preferably without interrupting my desktop session.
