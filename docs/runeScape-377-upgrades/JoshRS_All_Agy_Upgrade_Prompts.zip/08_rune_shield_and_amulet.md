# Rune Shield And Amulet

In my self-hosted RuneScape #377 server at ~/lostcity377/engine, give my character elrothiro a Rune kiteshield using the existing valid item definition and admin mechanisms. Equip it in the shield slot, preserving my sword, inventory, stats and save. If possible, also provide an Amulet of Fury, or the strongest supported alternative. Back up my save first, verify actual equipment bonuses, restart safely and confirm both items persist after relogging.
